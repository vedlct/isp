<!-- content -->
<footer class="footer">© 2018 <b>TechCloud Ltd</b> </footer>
</div>
<!-- End Right content here -->
</div>
<!-- END wrapper -->
<!-- jQuery  -->
<script src="{{url('public/js/jquery.min.js')}}"></script>
<script src="{{url('public/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{url('public/js/modernizr.min.js')}}"></script>
<script src="{{url('public/js/detect.js')}}"></script>
<script src="{{url('public/js/fastclick.js')}}"></script>
<script src="{{url('public/js/jquery.slimscroll.js')}}"></script>
<script src="{{url('public/js/jquery.blockUI.js')}}"></script>
<script src="{{url('public/js/waves.js')}}"></script>
<script src="{{url('public/js/jquery.nicescroll.js')}}"></script>
<script src="{{url('public/js/jquery.scrollTo.min.js')}}"></script>
<!-- skycons -->
<script src="{{url('public/plugins/skycons/skycons.min.js')}}"></script>
<!-- skycons -->
<script src="{{url('public/plugins/peity/jquery.peity.min.js')}}"></script>
<!--Morris Chart-->
{{--<script src="{{url('public/plugins/morris/morris.min.js')}}"></script>--}}
<script src="{{url('public/plugins/raphael/raphael-min.js')}}"></script>
<!-- dashboard -->
{{--<script src="{{url('public/pages/dashboard.js')}}"></script>--}}
<!-- App js -->
<script src="{{url('public/js/app.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>


@yield('js')
</body>
<!-- Mirrored from themesdesign.in/drixo/vertical/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 Nov 2018 08:38:33 GMT -->

</html>