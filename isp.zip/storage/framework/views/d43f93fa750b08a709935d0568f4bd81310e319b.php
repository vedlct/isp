<table id="datatable" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
    <tr>
        <th>Employee Name</th>
        <th>Employee Salary</th>
        <th>Status</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($employee->employeeName); ?></td>
            <td><?php echo e($employee->salary); ?></td>
            <td>
                <?php if($report->where('tabelId', $employee->employeeId)->first() == true): ?>
                    <div class="btn btn-info">Done</div>

                <?php else: ?>
                    <button class="btn btn-success">Pay  </button>
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>