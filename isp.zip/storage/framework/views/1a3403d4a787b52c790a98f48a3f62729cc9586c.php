<!-- content -->
<footer class="footer">© 2018 <b>TechCloud Ltd</b> </footer>
</div>
<!-- End Right content here -->
</div>
<!-- END wrapper -->
<!-- jQuery  -->
<script src="<?php echo e(url('public/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(url('public/js/detect.js')); ?>"></script>
<script src="<?php echo e(url('public/js/fastclick.js')); ?>"></script>
<script src="<?php echo e(url('public/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(url('public/js/jquery.blockUI.js')); ?>"></script>
<script src="<?php echo e(url('public/js/waves.js')); ?>"></script>
<script src="<?php echo e(url('public/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(url('public/js/jquery.scrollTo.min.js')); ?>"></script>
<!-- skycons -->
<script src="<?php echo e(url('public/plugins/skycons/skycons.min.js')); ?>"></script>
<!-- skycons -->
<script src="<?php echo e(url('public/plugins/peity/jquery.peity.min.js')); ?>"></script>
<!--Morris Chart-->

<script src="<?php echo e(url('public/plugins/raphael/raphael-min.js')); ?>"></script>
<!-- dashboard -->

<!-- App js -->
<script src="<?php echo e(url('public/js/app.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>


<?php echo $__env->yieldContent('js'); ?>
</body>
<!-- Mirrored from themesdesign.in/drixo/vertical/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 08 Nov 2018 08:38:33 GMT -->

</html>