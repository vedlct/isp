<?php $__env->startSection('css'); ?>


    <!-- DataTables -->
    <link href="<?php echo e(url('public/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(url('public/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(url('public/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    
    
    

    
    
    
    
    

    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    


    

    

    
    

    

    
    
    
    
    
    
    

    
    
    
    
    

    
    

    

    
    

    

    
    
    

    <div class="row">

        <div class="col-12">
            <div class="card m-b-30">
                <div class="card-body">

                    <h4 class="mt-0 header-title">Due Bill</h4>
                    
                        
                        
                    


                    <table id="datatable" class="table table-bordered  dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>IP</th>
                            <th>Package Name</th>
                            <th>BandWide</th>
                            <th>Price</th>
                            <th>Address</th>
                            <th>Date</th>
                            <th>Action</th>
                            <th>Invoice</th>
                        </tr>
                        </thead>

                        <tbody>
                        
                        <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($c->clientFirstName); ?></td>
                                <td><?php echo e($c->clientLastName); ?></td>
                                <td><?php echo e($c->ip); ?></td>
                                <td><?php echo e($c->packageName); ?></td>
                                <td><?php echo e($c->bandWide); ?></td>
                                <td><?php echo e($c->cprice); ?></td>
                                <td><?php echo e($c->address); ?></td>
                                <td>


                                    <select class="form-control" id="billtype" data-panel-date="<?php echo e($date); ?>" data-panel-id='<?php echo e($c->clientId); ?>' onchange="changebillstatus(this)">
                                        <option  value="paid" <?php if($bill->where('fkclientId', $c->clientId)->first() == true): ?> selected <?php else: ?> <?php endif; ?>>Paid</option>
                                        <option value="due" <?php if($bill->where('fkclientId', $c->clientId)->first() == false): ?> selected   <?php endif; ?>>Due</option>
                                    </select>
                                </td>

                                <td>
                                    <button class="btn btn-info btn-sm" data-panel-date="<?php echo e($date); ?>" data-panel-id="<?php echo e($c->clientId); ?>" onclick="generateBill(this)" ><i class="fa fa-print"></i></button>
                                </td>



                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>






                    </table>

                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(url('public/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/plugins/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/plugins/datatables/responsive.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(url('public/assets/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
    <script>

        $(document).ready( function () {
            $('.datepicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose:true,
                minViewMode: 1,

            });

            $('#datatable').DataTable({
                    responsive: true
                }
            );
        } );

        function generateBill(x) {
            var id = $(x).data('panel-id');
            var date = $(x).data('panel-date');

            let url = "<?php echo e(route('bill.invoice',[':id',':date'])); ?>";

            // url = url.replace([':id',':date'], id,date);
            url = url.replace(':date', date);
            url = url.replace(':id', id);
            //
            // document.location.href=url;

            window.open(url,'_blank')

        }
        function changeDate(x) {
            var date=$(x).val();

            // alert(date);
            let url = "<?php echo e(route('bill.show.date', ':date')); ?>";
            url = url.replace(':date', date);
            document.location.href=url;

        }

        function changebillstatus(x) {
            var id = $(x).data('panel-id');
            var date = $(x).data('panel-date');
            var billtype = document.getElementById('billtype').value;

            if (billtype == 'paid') {

                $.ajax({
                    type: 'POST',
                    url: "<?php echo route('bill.paid'); ?>",
                    cache: false,
                    data: {_token: "<?php echo e(csrf_token()); ?>", 'id': id,date:date},
                    success: function (data) {
                        //  $("#datatable").reload();

                        // alert(data);
                        // console.log(data);
                    }
                });
            }
            else {
                $.ajax({
                    type: 'POST',
                    url: "<?php echo route('bill.due'); ?>",
                    cache: false,
                    data: {_token: "<?php echo e(csrf_token()); ?>", 'id': id,date:date},
                    success: function (data) {
                        //  $("#datatable").reload();
                        location.reload();
                        // alert(data);
                        // console.log(data);
                    }
                });

            }
        }


        function editClient(x) {
            var id = $(x).data('panel-id');

            $.ajax({
                type: 'POST',
                url: "<?php echo route('client.edit'); ?>",
                cache: false,
                data: {_token: "<?php echo e(csrf_token()); ?>", 'id': id},
                success: function (data) {
                    $("#editModalBody").html(data);
                    $('#editModal').modal();
                    // console.log(data);
                }
            });
        }


        function getpackage() {
            var id = document.getElementById('package').value;

            $.ajax({
                type: 'POST',
                url: "<?php echo route('package.getpackage'); ?>",
                cache: false,
                data: {_token: "<?php echo e(csrf_token()); ?>", 'id': id},
                success: function (data) {
                    // $("#editModalBody").html(data);
                    // $('#editModal').modal();
                    // console.log(data);
                    //   $('bandwidth').val(data.bandwidth);
                    //  $('price').val(data.price);

                    document.getElementById('bandwidth').value = data.bandwidth;
                    document.getElementById('price').value = data.price;

                }
            });
        }



    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>