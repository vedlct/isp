<?php $__env->startSection('content'); ?>
    This Is The Homepage
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>