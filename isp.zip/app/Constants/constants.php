<?php

define('ACCOUNT_STATUS',array(
    "Debit"=>'debit',
    "Credit"=>'credit'
));








