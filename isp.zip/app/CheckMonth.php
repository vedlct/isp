<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CheckMonth extends Model
{
    //
    protected $table ='checkmonth';
    protected $primaryKey='id';
    public $timestamps = false;
}
