<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CablePackage extends Model
{

    protected $table ='cablepackage';
    protected $primaryKey='cablepackageId';
    public $timestamps = false;
}
